//https://leetcode.com/problems/merge-k-sorted-lists/



class Merge_K {
    public ListNode mergeKLists(ListNode[] lists) {
         ArrayList<Integer> arrayList = new ArrayList<Integer>();

        for (int i = 0; i < lists.length; i++) {
            while (lists[i] != null) {
                arrayList.add(lists[i].val);
                lists[i] = lists[i].next;
            }

        }
        Collections.sort(arrayList);

        ListNode head = new ListNode();
        ListNode answer = head;
        for (int i = 0; i < arrayList.size(); i++) {
            head.next = new ListNode(arrayList.get(i));
            head = head.next;

        }

        return answer.next;
    }
}